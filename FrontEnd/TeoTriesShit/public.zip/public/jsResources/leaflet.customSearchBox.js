// This is a trial of creating a custom search box
// Credits to:
// https://github.com/8to5Developer/leaflet-custom-searchbox/
